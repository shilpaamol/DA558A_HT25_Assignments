# DA558A HT25 Assignments/Labs

## Lab #1 - HTML & CSS
Enhanced Personal Portfolio

## Lab #2 - JavaScript along with HTML & CSS
Interactive Portfolio Enhancement Git Workflow
